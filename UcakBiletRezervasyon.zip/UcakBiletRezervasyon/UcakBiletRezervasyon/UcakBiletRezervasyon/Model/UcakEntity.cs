﻿namespace UcakBiletRezervasyon.Model;

public class UcakEntity
{
    public int Id { get; set; }
    public string Model { get; set; }
    public string Marka { get; set; }
    public string SeriNo { get; set; }
    public int KoltukSayisi { get; set; }
}